

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <tr>
        <td><?php echo e($index + 1); ?></td>
        <td><?php echo e($item->name); ?> </td>
        <td><a href="mailto:<?php echo e($item->email); ?>"><?php echo e($item->email); ?></a></td>
        <td><?php echo e($item->role); ?></td>
        <td><?php echo e($item->phone); ?></td>
        <td><?php echo e($item->notes); ?></td>
        <td style="display: flex; justify-content: center; position: relative;">

            <div class="btn-group btn-group-rounded">
                <button type="button" class="btn btn-default btn-xs row_drop_btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="border-radius:3px; background: none; border: none; outline: none; text-align:center;">
                    <i class="fa-solid fa-ellipsis"></i>
                </button>
                <ul class="dropdown-menu">
                    <li>
                        <a style="color: green; font-size: 15px; margin: 7px 10px 10px 0; cursor: pointer;" class="edit" data-action_type="edit" data-id="<?php echo e($item->id); ?>">
                            <i class="fa-solid fa-pen"></i> Edit
                        </a>
                    </li>

                    <li>
                        <a style="color: red; font-size: 15px; margin: 7px 10px 7px 0; cursor: pointer; " class="delete" data-action_type="delete" data-id="<?php echo e($item->id); ?>">
                            <i class="fa-solid fa-trash"></i> Delete
                        </a>
                    </li>
                </ul>
            </div>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH D:\Marketing Agency CRM\crm\resources\views/team/row.blade.php ENDPATH**/ ?>