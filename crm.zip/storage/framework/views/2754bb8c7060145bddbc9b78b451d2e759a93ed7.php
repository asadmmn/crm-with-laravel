

<footer class="footer">
    <small style="margin-bottom: 20px; display: inline-block">
        © 2023 made with
        <span style="color: red; font-size: 18px">&#10084;</span> by -
        <a target="_blank" href="#">
            ITB Tech
        </a>
    </small>
</footer>
<?php /**PATH D:\Marketing Agency CRM\crm\resources\views/layout/footer.blade.php ENDPATH**/ ?>