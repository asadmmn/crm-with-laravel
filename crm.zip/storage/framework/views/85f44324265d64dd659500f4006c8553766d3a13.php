<footer class="footer">
    <small style="margin-bottom: 20px; display: inline-block">
        © 2023 made with
        <span style="color: red; font-size: 18px">&#10084;</span> by -
        <a target="_blank" href="https://azouaoui.netlify.com">
            Mohamed Azouaoui
        </a>
    </small>
    <br />
    <div class="social-links">
        <a href="https://github.com/azouaoui-med" target="_blank">
            <i class="ri-github-fill ri-xl"></i>
        </a>
        <a href="https://twitter.com/azouaoui_med" target="_blank">
            <i class="ri-twitter-fill ri-xl"></i>
        </a>
        <a href="https://codepen.io/azouaoui-med" target="_blank">
            <i class="ri-codepen-fill ri-xl"></i>
        </a>
        <a href="https://www.linkedin.com/in/mohamed-azouaoui/" target="_blank">
            <i class="ri-linkedin-box-fill ri-xl"></i>
        </a>
    </div>
</footer><?php /**PATH D:\Marketing Agency CRM\crm\resources\views/essential_components/footer.blade.php ENDPATH**/ ?>