<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Password Reset</title>
</head>

<body>
    <h1>Reset Your password</h1>
    <h3>Click The link below to reset your password:</h3>
    <a href="<?php echo e($details['body']); ?>">Reset password</a>
</body>
</html>
<?php /**PATH D:\Marketing Agency CRM\crm\resources\views/mails/forgot-password.blade.php ENDPATH**/ ?>